This repository is an ongoing compilation of pygame examples.  Most were originally created with the intent of helping people with questions on various forums.  My goal is to write concise examples which demonstrate individual Pygame concepts, while still retaining a responsible coding style. The target audience are those who already have a firm grasp of Python and would like to give 2d graphics a try.

-Mek
